package com.joshua.stephens.repository

import com.joshua.stephens.data.StockDao
import com.joshua.stephens.data.StockInfo
import kotlinx.coroutines.flow.Flow

class StockRepository(private val stockDao: StockDao) {

    suspend fun insertStock(stock: StockInfo) = stockDao.insertStock(stock)

    suspend fun getAllStocks(): Flow<List<StockInfo>> = stockDao.getAllStocks()

    suspend fun getStockBySymbol(symbol: String) = stockDao.getStockBySymbol(symbol)
}
