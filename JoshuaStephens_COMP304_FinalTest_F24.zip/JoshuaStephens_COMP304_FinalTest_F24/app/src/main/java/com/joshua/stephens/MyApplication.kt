package com.joshua.stephens

import android.app.Application
import android.content.Context
import androidx.startup.Initializer
import com.joshua.stephens.data.AppDatabase

class MyApplication : Application(), Initializer<Unit> {

    override fun onCreate() {
        super.onCreate()

        AppDatabase.getInstance(this)
    }

    override fun create(context: Context): Unit {

    }

    override fun dependencies(): List<Class<out Initializer<*>>> {
        return emptyList()
    }
}
