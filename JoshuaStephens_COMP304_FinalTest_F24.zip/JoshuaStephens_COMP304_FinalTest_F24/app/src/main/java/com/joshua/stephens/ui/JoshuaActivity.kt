// Joshua A. Stephens (301215503)
package com.joshua.stephens.ui



import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.joshua.stephens.data.StockInfo
import com.joshua.stephens.viewmodel.StockViewModel

class JoshuaActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel: StockViewModel = viewModel()
            var stockSymbol by remember { mutableStateOf("") }
            var companyName by remember { mutableStateOf("") }
            var stockQuote by remember { mutableStateOf("") }
            val stockSymbols by viewModel.stockSymbols.collectAsState()

            Column(Modifier.padding(16.dp)) {
                BasicTextField(value = stockSymbol, onValueChange = { stockSymbol = it }, modifier = Modifier.padding(bottom = 8.dp))
                BasicTextField(value = companyName, onValueChange = { companyName = it }, modifier = Modifier.padding(bottom = 8.dp))
                BasicTextField(value = stockQuote, onValueChange = { stockQuote = it }, modifier = Modifier.padding(bottom = 16.dp))

                Button(onClick = {
                    if (stockSymbol.isNotEmpty() && companyName.isNotEmpty() && stockQuote.isNotEmpty()) {
                        try {
                            val stock = StockInfo(stockSymbol, companyName, stockQuote.toDouble())
                            viewModel.insertStock(stock)
                        } catch (e: NumberFormatException) {
                            Toast.makeText(this@JoshuaActivity, "Invalid stock quote", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this@JoshuaActivity, "All fields must be filled", Toast.LENGTH_SHORT).show()
                    }
                }) {
                    Text("Add Stock")
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn {
                    items(stockSymbols) { symbol ->
                        Text(symbol)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(onClick = {
                    if (stockSymbol.isNotEmpty()) {
                        val intent = Intent(this@JoshuaActivity, DisplayActivity::class.java)
                        intent.putExtra("stockSymbol", stockSymbol)
                        startActivity(intent)
                    } else {
                        Toast.makeText(this@JoshuaActivity, "Enter a valid stock symbol", Toast.LENGTH_SHORT).show()
                    }
                }) {
                    Text("Display Stock Info")
                }
            }
        }
    }
}
