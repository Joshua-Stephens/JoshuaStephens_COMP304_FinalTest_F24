package com.joshua.stephens.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.joshua.stephens.data.StockInfo
import com.joshua.stephens.repository.StockRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class StockViewModel(private val repository: StockRepository) : ViewModel() {
    private val _stockSymbols = MutableStateFlow<List<String>>(emptyList())
    val stockSymbols: StateFlow<List<String>> = _stockSymbols

    init {
        loadStockSymbols()
    }

    fun insertStock(stock: StockInfo) {
        viewModelScope.launch {
            try {
                repository.insertStock(stock)
                loadStockSymbols()
            } catch (e: Exception) {

            }
        }
    }

    fun loadStockSymbols() {
        viewModelScope.launch {
            try {
                repository.getAllStocks().collect { stockInfoList ->
                    if (stockInfoList.isNotEmpty()) {
                        _stockSymbols.value = stockInfoList.map { it.stockSymbol }
                    } else {
                        _stockSymbols.value = emptyList()
                    }
                }
            } catch (e: Exception) {

                _stockSymbols.value = emptyList()
            }
        }
    }




    suspend fun getStockBySymbol(symbol: String): StockInfo? {
        return try {
            repository.getStockBySymbol(symbol)
        } catch (e: Exception) {
            null
        }
    }
}
