package com.joshua.stephens.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StockDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStock(stock: StockInfo): Long

    @Delete
    suspend fun deleteStock(stock: StockInfo)

    @Update
    suspend fun updateStock(stock: StockInfo)

    @Query("SELECT * FROM stock_info WHERE stockSymbol = :symbol")
    suspend fun getStockBySymbol(symbol: String): StockInfo?

    @Query("SELECT * FROM stock_info")
    fun getAllStocks(): Flow<List<StockInfo>>
}



